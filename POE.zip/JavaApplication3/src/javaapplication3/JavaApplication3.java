/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication3;

import java.util.Scanner;
public class JavaApplication3 {

    private static final String USERNAME = "BONOLO";
    private static final String PASSWORD = "Bonolo_12345";
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("ENTER YOUR USERNAME");
        String username = input.nextLine();
        
        System.out.println("ENTER YOUR PASSWORD");
        String password = input.nextLine();
        
    }
    
}
